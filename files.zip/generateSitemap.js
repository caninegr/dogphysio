// generateSitemap.js
// This script automatically generates a sitemap.xml from your blog data
// Place this file in the root of your project and run: node generateSitemap.js

const fs = require('fs');
const path = require('path');

// Import your blog data
// Adjust the path based on where your blogs.js file is located
const { blogContent } = require('./src/data/blogs.js');

// Your website URL
const WEBSITE_URL = 'https://thetruthaboutdogs.gr';

// Generate XML for each blog post
const generateBlogUrls = () => {
  return blogContent.map(blog => {
    const lastmod = blog.sortDate || new Date().toISOString().split('T')[0];
    return `  <url>
    <loc>${WEBSITE_URL}/blog-article/${blog.id}</loc>
    <lastmod>${lastmod}</lastmod>
    <changefreq>monthly</changefreq>
    <priority>0.8</priority>
  </url>`;
  }).join('\n');
};

// Static pages (add/remove as needed)
const staticPages = [
  { path: '/', priority: '1.0', changefreq: 'weekly' },
  { path: '/blog', priority: '0.9', changefreq: 'weekly' },
  { path: '/contact', priority: '0.7', changefreq: 'monthly' },
  // Add more static pages here
];

const generateStaticUrls = () => {
  const today = new Date().toISOString().split('T')[0];
  return staticPages.map(page => {
    return `  <url>
    <loc>${WEBSITE_URL}${page.path}</loc>
    <lastmod>${today}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`;
  }).join('\n');
};

// Generate complete sitemap
const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${generateStaticUrls()}
${generateBlogUrls()}
</urlset>`;

// Write to public folder
const publicPath = path.join(__dirname, 'public', 'sitemap.xml');
fs.writeFileSync(publicPath, sitemap);

console.log('✅ Sitemap generated successfully!');
console.log(`📄 Location: ${publicPath}`);
console.log(`📊 Total URLs: ${staticPages.length + blogContent.length}`);
console.log(`\nTo verify: ${WEBSITE_URL}/sitemap.xml`);
